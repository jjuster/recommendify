class Recommendify::CosineInputMatrix < Recommendify::InputMatrix

  include Recommendify::CCMatrix
  
  # here be dragons ;)

end