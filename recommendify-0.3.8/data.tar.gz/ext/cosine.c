void calculate_cosine(char *item_id, int itemCount, struct cc_item *cc_items, int cc_items_size){
  /* here be dragons */
}
